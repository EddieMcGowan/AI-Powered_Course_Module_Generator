
Data and Input Information

The main file is streamlitapp.py. This file contains all our data processing and the functionality for the streamlit app.

The auxilarly file. "aux_1.ipynb" was used to develop the application. All the code in this application is available in streamlitapp.py. Feel free to review if interested, but no need to run. 

This project does not use a fixed dataset. Instead, it processes teacher-uploaded materials (PDFs, articles, web links, tables) at runtime. The model processes inputs in real time to generate personalized, structured lesson plans. Please note that this customization requires a few minutes of processing time.


By adapting the prompt, the model can adjust to different teaching styles without requiring additional model training.

I have included an example PDF and an example URL for testing:
- For PDFs: Upload the file directly into the model.
- For URLs: Copy and paste the link into the model.  

Tip: For faster runtime, I recommend using shorter PDFs or webpages (approximately 3–8 pages).


Troubleshooting

If you encounter any issues, please follow these steps:

1. Accessing the Streamlit App:  
   - Ensure you are connected to the Lehigh VPN.  
   - If you are connected but still cannot access the app, refer to the setup instructions in the README for running the code locally.  
   - Alternatively, you may email Eddie (wem220@lehigh.edu) and Alex (alk723@lehigh.edu) for support.

2. CUDA Out of Memory Error:  
   - If multiple processes are running simultaneously on the magic02 server, the model may not have enough GPU memory to run.  
   - Typically, another GPU on magic02 has more memory available.  
   - I recommend changing the GPU backend for Streamlit (instructions are provided in the README) and rerunning the application.

3. Other Issues:  
   - For any other challenges, please contact Eddie (wem220@lehigh.edu) and Alex (alk723@lehigh.edu).
